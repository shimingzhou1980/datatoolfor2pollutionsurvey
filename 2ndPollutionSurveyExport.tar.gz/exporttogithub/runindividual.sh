#!/bin/bash
topdir=/pucha/puchatool/
cd /pucha/puchatool/
#./bin/autologin.py
#./updatejsessionid.sh
cd ./individual
./queryCodeId.sh
for i in ./queryTableUUID-*.sh ;do
 ./$i ;
done

##保存数据
#默认以日期作为文件夹
if [ $# -eq 2 ]  ;then  
datadir= "$1"
else
datadir=`date  "+%Y-%m-%d-%H-%M-%S"`
fi
mkdir  -p  $topdir/data/individual/$datadir/
cp -rf  ./result/*gongye* ./result/*nongye*/ ./result/*jizhongshi*  ./result/*yidongyuan*    $topdir/data/$datadir/individual/
