#!/bin/bash
topdir="`realpath $0 |sed -s 's/[^\/]*$//g'`"
cd "$topdir"

if [ $# -gt 1 ] ;then 
jsessionid="$1" 
echo $jsessionid >./jsessionid.txt
else
###auto login  
./bin/autologin.py
fi
./updatejsessionid.sh
cd ./run
./runhuizong.sh
./runbasetable.sh
./saveresult.sh


###
ip=`ifconfig |grep inet |grep -v inet6 |sed 's/^ *//g'  |cut -d' ' -f2|cut -d':' -f2|head -n1`
echo "请通过以下网络邻居地址访问导出的数据的最新版本(注意由于时间不同步原因，导出目录时间为虚拟机系统时间:"
echo '\\'"$ip"'\'""

killall chromedriver
killall chromedriver
echo "请按回车键结束！"
read
