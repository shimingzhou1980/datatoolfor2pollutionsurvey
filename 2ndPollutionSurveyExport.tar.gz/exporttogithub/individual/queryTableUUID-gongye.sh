#!/bin/bash
tmpfile=./result/temp.html
jsonfile=./result/codeid/codeid-gongye.json 
pucha=./result/puchalist.txt
mkdir -p  ./result/gongye/
mkdir -p  ./result/nongye/
mkdir -p  ./result/yidong/
mkdir -p  ./result/shenghuo/



curl 'http://10.45.100.185/wrpc/resource/js/wrpc/watchforms/watchforms.js?v=v5.7' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf'  >$tmpfile

##generate reportidmap
cat $tmpfile   |sed   -n  '/wrpc.watchforms.formMap =/,/}/p'    |sed 's/\t//g'|grep  '^"' |sed s'/,*//g'  > wrpc.watchforms.formMap.txt

cat $tmpfile   |sed   -n  '/wrpc.watchforms.reportMap =/,/}/p'    |sed 's/\t//g'|grep  '^"' |sed s'/,*//g'  > wrpc.watchforms.reportMap.txt

cat $tmpfile   |sed   -n  '/wrpc.watchforms.whsReportMap =/,/}/p'    |sed 's/\t//g'|grep  '^"' |sed s'/,*//g'  > wrpc.watchforms.whsReportMap.txt

cat $tmpfile   |sed   -n  '/wrpc.watchforms.xubiaoMap =/,/}/p'    |sed 's/\t//g'|grep  '^"' |sed s'/,*//g'  > wrpc.watchforms.xubiaoMap.txt

cat $tmpfile   |sed   -n  '/wrpc.watchforms.nosubMap =/,/}/p'    |sed 's/\t//g'|grep  '^"' |sed s'/,*//g'  > wrpc.watchforms.nosubMap.txt

cat $tmpfile   |sed   -n  '/wrpc.watchforms.reportForPrintMap =/,/}/p'    |sed 's/\t//g'|grep  '^"' |sed s'/,*//g'  > wrpc.watchforms.reportForPrintMap.txt

#rm  "$tmpfile"





##

#获取企业信息
#按 名称 行政区划代码  CID 代码  普查小区代码  的顺序
cat $jsonfile  |jq '.list[]|(.UNITNAME,.UNIT_UID,.ID,.PCXQDM)' > "$pucha"

###循环导出数据
while read     name;read xzqhdm;read  cid;read  pcxqdm
do 
name=`echo $name |sed 's/"//g'`
cid=`echo $cid |sed 's/"//g'`
pcxqdm=`echo $pcxqdm |sed 's/"//g'`
xzqhdm=`echo $xzqhdm |sed 's/"//g'`





###读取报表map词典

curl 'http://10.45.100.185/wrpc/wrpc/common/getNextFromListByCid' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"CID":"'$cid'"}' |jq   '.[]|{"FORMID","TYPE"}'   |sed 's/^ *//g' |grep '^"'  |sed -z 's/,\n/@@@/g'  |awk -F '@@@'    'BEGIN{OFS=""}{split($1,reportid,":"); print "{\"reportId\":@"reportid[2]"@,\"params\":{"$2"}}"}' |sed 's/\([@:]\) */\1/g' |sed 's/FORMID/FK_ID/g' >./result/tmpreport.txt

##构造有核算post 参数
###系统默认有核算导出
postdata=`/pucha/puchatool/bin/individual-build-postdata.py ./wrpc.watchforms.reportMap.txt  ./result/tmpreport.txt`

####  构造post 导出数据
data='batch=true&singleFile=true&autoSheetName=true&customFileName='$name'&reports='$postdata

mkdir -p "./result/gongye/$xzqhdm/"
outputfilename="./result/gongye/$xzqhdm/${xzqhdm}-${pcxqdm}-${name}.xlsx"

###如果文件已经存在
#if [ -f "./gongye/$xzqhdm/$outputfile" ] ; do 
#	let i=1
#
#     outputfile="${outputfile}-$i"


curl 'http://10.45.100.182:8090/report_pro/Report-ExcelAction.do' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55' -H 'Upgrade-Insecure-Requests: 1' --data "$data" >"${outputfilename}"



####由于系统目前无核算结果导出与有核算结果导出完全一样，所以放弃无核算结果导出
###无核算

#curl 'http://10.45.100.185/wrpc/wrpc/common/getNextFromListByCid' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"CID":"'$cid'"}' |jq   '.[]|{"FORMID","TYPE"}'   |sed 's/^ *//g' |grep '^"'  |sed -z 's/,\n/@@@/g'  |awk -F '@@@'    'BEGIN{OFS=""}{split($1,reportid,":"); print "{\"reportId\":@"reportid[2]"@,\"params\":{"$2"}}"}' |sed 's/\([@:]\) */\1/g' |sed 's/FORMID/FK_ID/g' >./result/whstmpreport.txt
####无核算导出参数
#whspostdata=`/pucha/puchatool/bin/individual-build-postdata.py ./wrpc.watchforms.whsReportMap.txt  ./result/whstmpreport.txt`
#
#whsdata='batch=true&singleFile=true&autoSheetName=true&customFileName='$name'&reports='$whspostdata
#
#mkdir -p "./result/gongye-whs/$xzqhdm/"
#whsoutputfilename="./result/gongye-whs/$xzqhdm/${xzqhdm}-${pcxqdm}-${name}.xlsx"
#
#curl 'http://10.45.100.182:8090/report_pro/Report-ExcelAction.do' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55' -H 'Upgrade-Insecure-Requests: 1' --data "$data" >"${whsoutputfilename}"

##############构造归档格式
##############

curl 'http://10.45.100.185/wrpc/wrpc/common/getFromListByCidForPrint' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf'  --data '{"CID":"'$cid'"}' | jq 'map(.PA=(.PA|tostring))'| jq 'map(if .PA=="null"  then  .PA="undefined" else . end)' |jq 'map(select(.FORMID !=null))' |jq  '.[]|{"PA","FORMID","TYPE"}'   |sed 's/^ *//g' |grep '^"'  |sed -z 's/,\n/@@@/g'  |awk -F '@@@'    'BEGIN{OFS=""}{split($1,reportid,":"); print "{\"reportId\":@"reportid[2]"@,\"params\":{"$3","$2"}}"}'| sed 's/\([@:]\) */\1/g' |sed 's/FORMID/FK_ID/g'>./result/tmpreport-pa.txt

#curl 'http://10.45.100.185/wrpc/wrpc/common/getFromListByCidForPrint' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"CID":"'$cid'"}' |jq   '.[]|{"FORMID","TYPE"}'   |sed 's/^ *//g' |grep '^"'  |sed -z 's/,\n/@@@/g'  |awk -F '@@@'    'BEGIN{OFS=""}{split($1,reportid,":"); print "{\"reportId\":@"reportid[2]"@,\"params\":{"$2",\"PA\":\"1\"}}"}' |sed 's/\([@:]\) */\1/g' |sed 's/FORMID/FK_ID/g' >./result/tmpreport-pa.txt

##构造归档打印格式的post 参数
papostdata=`/pucha/puchatool/bin/individual-build-postdata.py ./wrpc.watchforms.reportForPrintMap.txt  ./result/tmpreport-pa.txt`

####  构造post 导出数据
data='batch=true&singleFile=true&autoSheetName=true&customFileName='$name'&reports='$papostdata

mkdir -p "./result/gongye-归档格式/$xzqhdm/"
outputfilename="./result/gongye-归档格式/$xzqhdm/${xzqhdm}-${pcxqdm}-${name}.xlsx"


###下载归档文档

curl 'http://10.45.100.182:8090/report_pro/Report-ExcelAction.do' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55' -H 'Upgrade-Insecure-Requests: 1' --data "$data" >"${outputfilename}"




done < $pucha

