#!/bin/bash
toolrootdir=`pwd`/../
./updatejsessionid.sh
mydir="nongye"
cd ./$mydir 
for i in *.sh ;do
    ./$i 
done
cd $toolrootdir

cd ./huizong/$mydir
for i in *.sh ;do
    ./$i
done
cd $toolrootdir
