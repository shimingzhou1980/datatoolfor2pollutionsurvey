if [ $# -lt 1  ] ; then 
   echo usage:$0 sourcedatadir  accesstooldatadir
   exit 1
fi
datadir="$1"
if [ $# -ge 2 ] ; then 
  accessdatadir="$2"
else 
  accessdatadir=$datadir/accesstooldata/
fi
mkdir -p $accessdatadir
#cd $datadir

#工业源审核工具文件

mkdir -p $accessdatadir/gongye 
#复制工业基表,工业源只有基表，无汇总表

originname=("G101-1.xlsx"   "G101-2-B.xlsx"  "G101-3-C.xlsx"  "G101-3-D.xlsx" "G102-C.xlsx" "G102-D.xlsx" "G103-1-B.xlsx"  "G103-2-B.xlsx"  "G103-3-B.xlsx"  "G103-4-B.xlsx"  "G103-5-B.xlsx"  "G103-6-B.xlsx"  "G103-7-B.xlsx"  "G103-8-B.xlsx"  "G103-9-B.xlsx"  "G103-10-B.xlsx"  "G103-11-B.xlsx"  "G103-12-B.xlsx"  "G103-13.xlsx" "G104-1-A.xlsx" "G104-2-B.xlsx" "G105-C.xlsx" "G105-D.xlsx" "G106-1-B.xlsx" "G106-2-B.xlsx" "G106-3-B.xlsx" "G107-B.xlsx" "G107-1-B.xlsx" "G107-2-B.xlsx"  "G108-B.xlsx")
mapname=(  "G101-1.xlsx" "G101-2.xlsx"  "G101-3_1.xlsx"  "G101-3_2.xlsx" "G102_1.xlsx" "G102_2.xlsx" "G103-1.xlsx"  "G103-2.xlsx"  "G103-3.xlsx"  "G103-4.xlsx"  "G103-5.xlsx"  "G103-6.xlsx"  "G103-7.xlsx"  "G103-8.xlsx"  "G103-9.xlsx"  "G103-10.xlsx"  "G103-11.xlsx"  "G103-12.xlsx"  "G103-13.xlsx" "G104-1.xlsx" "G104-2.xlsx" "G105_1.xlsx" "G105_2.xlsx" "G106-1.xlsx" "G106-2.xlsx" "G106-3.xlsx" "G107.xlsx" "G107-1.xlsx" "G107-2.xlsx" "G108_1.xlsx")

mkdir -p "$accessdatadir/gongye/"
let count=0
let  namelength=${#originname[@]} 
for i in `seq 0 $(($namelength-1))` ;do 
         if  [ -f "$datadir/origin/gongye/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/gongye/${originname[$i]}"  "$accessdatadir/gongye/${mapname[$i]}" 
	 fi
         let count=$count+1
done
echo "复制工业源基表文件 $count 个."
#复制工业access审核工具所需的三个生活源表
originname=(  "J101-1.xlsx" "J101-2.xlsx" "J101-3-B.xlsx")
mapname=(  "J101-1.xlsx" "J101-2.xlsx" "J101-3.xlsx")

let count=0
let  namelength=${#originname[@]} 
for i in `seq 0 $(($namelength-1))` ;do 
         if  [ -f "$datadir/origin/jizhongshi/${originname[$i]}" ]  ; then
		   cp   "$datadir/origin/jizhongshi/${originname[$i]}"  "$accessdatadir/gongye/${mapname[$i]}"
       		  let count=$count+1
	fi
done
echo "复制了$count 个集中式基表到工业源审核工具"

#=========================================================================================================
#处理农业
#农业源审核工具文件

mkdir -p $accessdatadir/nongye 
#复制农业基表

originname=(  "N101-1.xlsx" "N101-2.xlsx"  "N201-1.xlsx"  "N201-2.xlsx" "N201-3.xlsx" "N202.xlsx" "N203.xlsx"  "NH101.xlsx"  "NH102.xlsx"  "NH103.xlsx"  "NH104.xlsx"  "NH105.xlsx"  "NH105-1.xlsx"  "NH106.xlsx"  "NH108.xlsx" )
mapname=(  "N101-1.xlsx" "N101-2.xlsx"  "N201-1.xlsx"  "N201-2.xlsx" "N201-3.xlsx" "N202.xlsx" "N203.xlsx"  "NH101.xlsx"  "NH102.xlsx"  "NH103.xlsx"  "NH104.xlsx"  "NH105.xlsx"  "NH105-1.xlsx"  "NH106.xlsx"  "NH108.xlsx" )

let count=0
mkdir -p "$accessdatadir/nongye/"
let  namelength=${#originname[@]} 
for i in `seq 0 $(($namelength-1))` ;do 
         if  [ -f "$datadir/origin/nongye/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/nongye/${originname[$i]}"  "$accessdatadir/nongye/${mapname[$i]}" 
	 fi
#######汇总表#####
         if  [ -f "$datadir/origin/nongye/huizong/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/nongye/huizong/${originname[$i]}"  "$accessdatadir/nongye/${mapname[$i]}" 
	 fi
         let count=$count+1
done
echo "复制农业源文件 $count 个."


##=========================================================================================================
#集中式

mkdir -p $accessdatadir/jizhongshi
#复制集中式基表

originname=( "J101-1.xlsx" "J101-2.xlsx"  "J101-3-B.xlsx"  "J102-1.xlsx"  "J102-2.xlsx"    "J103-1.xlsx"  "J103-2.xlsx" "J104-1.xlsx" "J104-2.xlsx" "J104-3.xlsx" )
mapname=(  "J101-1.xlsx" "J101-2.xlsx"  "J101-3.xlsx"  "J102-1.xlsx"  "J102-2.xlsx"    "J103-1.xlsx"  "J103-2.xlsx" "J104-1.xlsx" "J104-2.xlsx" "J104-3.xlsx" )

let count=0
mkdir -p "$accessdatadir/jizhongshi/"
let  namelength=${#originname[@]} 
for i in `seq 0 $(($namelength-1))` ;do 
         if  [ -f "$datadir/origin/jizhongshi/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/jizhongshi/${originname[$i]}"  "$accessdatadir/jizhongshi/${mapname[$i]}" 
	 fi
         let count=$count+1
done
echo "复制集中式源基表文件 $count 个."


##=========================================================================================================
#处理生活源
#生活源源审核工具文件

mkdir -p $accessdatadir/shenghuoyuan 
#复制生活源基表

originname=(  "S101.xlsx" "S102.xlsx"  "S103.xlsx"  "S104.xlsx" "S105.xlsx" "S201.xlsx"   "SH102-1.xlsx"  "SH103-1.xlsx"  "SH104-1.xlsx"  "SH201-1.xlsx"  "SH201-2.xlsx"  "SH201-3.xlsx" "SH202.xlsx" "SH203.xlsx")
mapname=(  "S101.xlsx" "S102.xlsx"  "S103.xlsx"  "S104.xlsx" "S105.xlsx" "S201.xlsx"   "SH102-1.xlsx"  "SH103-1.xlsx"  "SH104-1.xlsx"  "SH201-1.xlsx"  "SH201-2.xlsx"  "SH201-3.xlsx" "SH202.xlsx" "SH203.xlsx")

let count=0
mkdir -p "$accessdatadir/shenghuoyuan/"
let  namelength=${#originname[@]} 
for i in `seq 0 $(($namelength-1))` ;do 
         if  [ -f "$datadir/origin/shenghuoyuan/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/shenghuoyuan/${originname[$i]}"  "$accessdatadir/shenghuoyuan/${mapname[$i]}" 
	 fi
#######汇总表#####
         if  [ -f "$datadir/origin/shenghuoyuan/huizong/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/shenghuoyuan/huizong/${originname[$i]}"  "$accessdatadir/shenghuoyuan/${mapname[$i]}" 
	 fi
         let count=$count+1
done
echo "复制生活源源文件 $count 个."
##############################################################################

#处理移动源
#移动源源审核工具文件

mkdir -p $accessdatadir/yidongyuan
#复制移动源基表

originname=(  "Y101-A.xlsx" "Y101-B.xlsx" "Y101-C.xlsx"  "Y102.xlsx"  "Y103.xlsx"  "Y201-2.xlsx" "Y202-1.xlsx" "Y202-2.xlsx" "Y202-3.xlsx" "Y202-4.xlsx"  "Y203.xlsx"   "Y101-1.xlsx"  "Y101-2.xlsx"  "Y101-3.xlsx"  "YH101.xlsx"  "YH102.xlsx"  "YH103.xlsx" "YH104.xlsx"  "YH105.xlsx"  "YH106.xlsx" "YH110.xlsx" )
mapname=(  "Y101_1.xlsx" "Y101_2.xlsx" "Y101_3.xlsx"  "Y102.xlsx"  "Y103.xlsx"  "Y201-2.xlsx" "Y202-1.xlsx" "Y202-2.xlsx" "Y202-3.xlsx" "Y202-4.xlsx"  "Y203.xlsx"   "Y101-1.xlsx"  "Y101-2.xlsx"  "Y101-3.xlsx"  "YH101.xlsx"  "YH102.xlsx"  "YH103.xlsx" "YH104.xlsx"  "YH105.xlsx"  "YH106.xlsx" "YH110.xlsx" )

let count=0
mkdir -p "$accessdatadir/yidongyuan/"
let  namelength=${#originname[@]} 
for i in `seq 0 $(($namelength-1))` ;do 
         if  [ -f "$datadir/origin/yidongyuan/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/yidongyuan/${originname[$i]}"  "$accessdatadir/yidongyuan/${mapname[$i]}" 
	 fi
#######汇总表#####
         if  [ -f "$datadir/origin/yidongyuan/huizong/${originname[$i]}" ]  ; then
	   cp   "$datadir/origin/yidongyuan/huizong/${originname[$i]}"  "$accessdatadir/yidongyuan/${mapname[$i]}" 
	 fi
         let count=$count+1
done
echo "复制移动源源文件 $count 个."
