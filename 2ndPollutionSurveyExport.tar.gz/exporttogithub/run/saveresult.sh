#!/bin/bash
topdir=`pwd`/..
cd $topdir
#以日期作为文件夹
if [ $# -eq 2 ]  ;then  
datadir= "$1"
else
datadir=`date  "+%Y-%m-%d-%H-%M-%S"`
fi
mkdir  -p  data/$datadir/origin/{gongye,nongye,jizhongshi,shenghuoyuan,yidongyuan}/
mkdir  -p  data/$datadir/origin/huizong/{gongye,nongye,jizhongshi,shenghuoyuan,yidongyuan,allpollute}/



for i in gongye  nongye jizhongshi shenghuoyuan yidongyuan ;do 

#复制基表数据
mkdir -p $topdir/data/$datadir/origin/$i/huizong/
cp -rf huizong/$i/result/* $topdir/data/$datadir/origin/$i/huizong/
cp -rf  $i/result/*   $topdir/data/$datadir/origin/$i/

done

mkdir -p $topdir/data/$datadir/origin/allpollute/
cp -rf  huizong/allpollute/result/*   $topdir/data/$datadir/origin/allpollute/

#mkdir  -p  data/$datadir/access审核工具数据/
#名录库
mkdir -p $topdir/data/$datadir/origin/mingluku
cp -rf  mingluku/result/*   $topdir/data/$datadir/origin/mingluku/
