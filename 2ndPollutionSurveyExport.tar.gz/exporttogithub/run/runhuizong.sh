#!/bin/bash
rundir=`pwd`

for mydir in jizhongshi  shenghuoyuan  yidongyuan  gongye  nongye allpollute ;do
cd ../huizong/$mydir
for i in *.sh ;do
    ./$i
done
cd $rundir
done
