#!/bin/bash
toolrootdir=`pwd`
./updatejsessionid.sh
mydir="jizhongshi"
cd ../$mydir 
for i in *.sh ;do
    ./$i 
done
cd $toolrootdir

cd ../huizong/$mydir
for i in *.sh ;do
    ./$i
done
cd $toolrootdir
