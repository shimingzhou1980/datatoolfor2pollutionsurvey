#!/bin/bash
rundir=`pwd`
for mydir in jizhongshi  shenghuoyuan  yidongyuan  gongye  nongye;do
cd ../$mydir 
for i in *.sh ;do
    ./$i 
done
cd $rundir
done
