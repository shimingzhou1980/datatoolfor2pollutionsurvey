find huizong/ jizhongshi/  shenghuoyuan/ nongye/ yidongyuan/ gongye/ mingluku/ individual/   -type f -path '*.sh'  -exec   ./bin/replacesessionid.sh  `cat ./jsessionid.txt  `  {}  \;
