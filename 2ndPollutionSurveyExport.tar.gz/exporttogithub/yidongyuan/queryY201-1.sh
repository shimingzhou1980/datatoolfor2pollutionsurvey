#!/bin/bash
###because post data is too long to accept by bash script ,we have to post the data in a file 
###and load it by curl
#query
curl 'http://10.45.100.185/wrpc/wrpc/dataquery/getPageBuziDataList' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -d @queryY201-1.data.txt >/dev/null

#export
curl 'http://10.45.100.185/wrpc/wrpc/dataquery/exportExcelNew' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -H 'Upgrade-Insecure-Requests: 1' -d @Y201-1.export.data.txt >./result/Y201-1.xlsx
