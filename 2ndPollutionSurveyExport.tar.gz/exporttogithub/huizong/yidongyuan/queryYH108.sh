#!/bin/bash
#===query for YH108
##=export YH108
