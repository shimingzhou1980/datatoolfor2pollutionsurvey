#!/bin/bash
areacode="450000"
####默认为工业源:gyy,农业源:nyy,生活源:shy,集中式:jzs;移动源:ydy
###废气
PCode=("EYHLPFL" "DYHWPFL" "KLWPFL" "HFXYJWPFL" "ZAPFL" "ZSPFL" "ZQPFL" "ZGPFL" "ZCRPFL" "ZHGPFL")
PName=("二氧化硫（万吨）" "氮氧化物（万吨）" "颗粒物（万吨）" "挥发性有机物（吨）" "氨（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）")

len=${#PCode[*]}

echo "########行政区划代码$areacode的气污染物排放统计情况####"
let i=0
while ( [ $i -lt  $len ]  )
do 
####由于普查软件查询返回格式不规范，不同污染物有的有全市，有的污染物没有，所以必须在循环里处理

 curl 'http://10.45.100.185/wrpc/wrpc/stats/pollutantSource/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view;jsessionid=B9129F3E837EE1FBC5F04AB61400E9FA?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":'"\"$areacode\""',"contaminant":"fq","contaminantDetail":'"\"${PCode[$i]}\"}"   >/dev/null 
 curl 'http://10.45.100.185/wrpc/wrpc/stats/pollutantSource/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view;jsessionid=B9129F3E837EE1FBC5F04AB61400E9FA?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":'"\"$areacode\""',"contaminant":"fq","contaminantDetail":'"\"${PCode[$i]}\"}"  >./result/"分源-气-${PName[$i]}.xlsx" 
let i=$i+1
done

###废水
PCode=("HXXYLPFL" "ADPFL" "ZDPFL" "ZLPFL" "SYLPFL" "HFFPFL" "QHWPFL" "ZSPFL" "ZQPFL" "ZGPFL" "ZCRPFL" "ZHGPFL" "WRSHXYLPFL" "DZWYPFL")
PName=("化学需氧量（万吨）" "氨氮（万吨）" "总氮（万吨）" "总磷（万吨）" "石油类（万吨）" "挥发酚（吨）" "氰化物（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）" "五日生化需氧量（吨）" "动植物油（吨）")
len=${#PCode[*]}
echo "########行政区划代码$areacode的水污染物排放统计情况####"
let i=0
while ( [ $i -lt  $len ]  )
do 
####由于普查软件查询返回格式不规范，不同污染物有的有全市，有的污染物没有，所以必须在循环里处理
 curl 'http://10.45.100.185/wrpc/wrpc/stats/pollutantSource/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view;jsessionid=B9129F3E837EE1FBC5F04AB61400E9FA?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":'"\"$areacode\""',"contaminant":"fs","contaminantDetail":'"\"${PCode[$i]}\"}"   >/dev/null
  curl 'http://10.45.100.185/wrpc/wrpc/stats/pollutantSource/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view;jsessionid=B9129F3E837EE1FBC5F04AB61400E9FA?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":'"\"$areacode\""',"contaminant":"fs","contaminantDetail":'"\"${PCode[$i]}\"}"  >./result/"分源-水-${PName[$i]}.xlsx"
let i=$i+1

done

