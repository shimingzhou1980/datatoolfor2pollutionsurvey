#!/bin/bash
export PATH=$PATH:/pucha/puchatool/bin
CityName=("南宁市" "柳州市" "桂林市" "梧州市" "北海市" "防城港市" "钦州市" "贵港市" "玉林市" "百色市" "贺州市" "河池市" "来宾市" "崇左市" )
CityCode=("450100" "450200" "450300" "450400" "450500" "450600" "450700" "450800" "450900" "451000" "451100" "451200" "451300" "451400" )


lencity=${#CityName[*]}
let k=0 
while ( [ $k -lt  $lencity ]  )
do 

 
outputdir="./result/分行业统计/${CityName[$k]}/气/"
mkdir -p $outputdir
tmpfile="${outputdir}/tmp.txt"
 


####默认为工业源:gyy,农业源:nyy,生活源:shy,集中式:jzs;移动源:ydy
###废气
PCode=("EYHL" "DYHW" "KLW" "HFXYJW" "ZA" "ZS" "ZQ" "ZG" "ZCR" "ZHG")
PName=("二氧化硫（吨）" "氮氧化物（吨）" "颗粒物（吨）" "挥发性有机物（吨）" "氨（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）")

len=${#PCode[*]}

echo "########行政区划代码$areacode的气污染物排放统计情况####"
let i=0
while ( [ $i -lt  $len ]  )
do 

curl 'http://10.45.100.185/wrpc/wrpc/stats/industry/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":"'${CityCode[$k]}'","contaminant":"fq","contaminantDetail":"'${PCode[$i]}'"}' > "${outputdir}/气-${PName[$i]}.json"


##json转换成一个xlsx 文件

jsonfile="${outputdir}/气-${PName[$i]}.json"
cat "$jsonfile" |jq   .data|sed -z 's/\n//g' |sed 's/  */ /g' > "$tmpfile"
js2xlsx-huizong-queryfenhangyeByCity.py  "$tmpfile"  "${outputdir}/气-${PName[$i]}.xlsx"

let i=$i+1
done

###废水
outputdir="./result/分行业统计/${CityName[$k]}/水/"
mkdir -p $outputdir
tmpfile="${outputdir}/tmp.txt"
 

###系统已取消BOD5的导出
PCode=("HXXYL" "AD" "ZD" "ZL" "SYL" "HFF" "QHW" "ZS" "ZQ" "ZG" "ZCR" "ZHG"  )
PName=("化学需氧量（万吨）" "氨氮（万吨）" "总氮（万吨）" "总磷（万吨）" "石油类（万吨）" "挥发酚（吨）" "氰化物（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）" )
#PCode=("HXXYL" "AD" "ZD" "ZL" "SYL" "HFF" "QHW" "ZS" "ZQ" "ZG" "ZCR" "ZHG" "WRSHXYL" "DZWY")
#PName=("化学需氧量（万吨）" "氨氮（万吨）" "总氮（万吨）" "总磷（万吨）" "石油类（万吨）" "挥发酚（吨）" "氰化物（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）" "五日生化需氧量（吨）" "动植物油（吨）")
len=${#PCode[*]}
let i=0
while ( [ $i -lt  $len ]  )
do 

curl 'http://10.45.100.185/wrpc/wrpc/stats/industry/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":"'${CityCode[$k]}'","contaminant":"fs","contaminantDetail":"'${PCode[$i]}'"}' > "${outputdir}/水-${PName[$i]}.json"



##json转换成xlsx 
jsonfile="${outputdir}/水-${PName[$i]}.json"
cat "$jsonfile" |jq   .data|sed -z 's/\n//g' |sed 's/  */ /g' > "$tmpfile"
js2xlsx-huizong-queryfenhangyeByCity.py  "$tmpfile"  "${outputdir}/水-${PName[$i]}.xlsx"


let i=$i+1

done



###
let k=$k+1
done
