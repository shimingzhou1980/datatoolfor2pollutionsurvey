#!/bin/bash
####默认为工业源:gyy,农业源:nyy,生活源:shy,集中式:jzs;移动源:ydy
###废气
PCode=("EYHL" "DYHW" "KLW" "HFXYJW" "ZA" "ZS" "ZQ" "ZG" "ZCR" "ZHG")
PName=("二氧化硫（万吨）" "氮氧化物（万吨）" "颗粒物（万吨）" "挥发性有机物（吨）" "氨（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）")

len=${#PCode[*]}
mkdir -p ./result/分行业统计

echo "########行政区划代码$areacode的气污染物排放统计情况####"
let i=0
while ( [ $i -lt  $len ]  )
do 

curl 'http://10.45.100.185/wrpc/wrpc/stats/industry/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: UserLocationfp=http%3A//10.45.100.189/pollution_survey_mybatis_ministry/login/ssoLogin.do%3FpageType%3D3%26ua_account%3D450000893; JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":"450000","contaminant":"fq","contaminantDetail":"'${PCode[$i]}'"}' >./result/分行业统计/"分行业-气-${PName[$i]}.json"
##json转换导 csv


if [ -s ./result/分行业统计/"分行业-气-${PName[$i]}.json" ] ;then 
###表格标题行名称"
#cat ./result/分行业统计/"分行业-气-${PName[$i]}.json" | jq  .data[0]|grep -v '[{}]'  |sed 's/^ *//'|cut -d':' -f1 |sed -z 's/\n/,/g' |sed 's/,$//g' >./result/分行业统计/"分行业-气-${PName[$i]}.csv"

#jsonheader=`cat ./result/分行业统计/"分行业-气-${PName[$i]}.json" | jq  .data[0]|grep -v '[{}]'  |sed 's/^ *//'|cut -d':' -f1 |sed -z 's/\n/,/g' |sed 's/,$//g' |sed 's@\"\([^ \"]*\)\"@\\\\(.\1@g'`

#jqoption="\'.data[]|\"$jsonheader\" \'"
#cat ./result/分行业统计/"分行业-气-${PName[$i]}.json"  |jq --raw-output "$jqoption" >>./result/分行业统计/"分行业-气-${PName[$i]}.csv"
cat  ./result/分行业统计/"分行业-气-${PName[$i]}.json"  |jq -c '.data'  >./result/分行业统计/tmpjson.json
/pucha/puchatool/bin/js2xlsx-huizong-fenhangye.py ./result/分行业统计/tmpjson.json ./result/分行业统计/"分行业-气-${PName[$i]}.xlsx"


fi 
##查询结果直接就是json格式的报表数据


let i=$i+1
done

###废水
PCode=("HXXYL" "AD" "ZD" "ZL" "SYL" "HFF" "QHW" "ZS" "ZQ" "ZG" "ZCR" "ZHG"  )
PName=("化学需氧量（万吨）" "氨氮（万吨）" "总氮（万吨）" "总磷（万吨）" "石油类（万吨）" "挥发酚（吨）" "氰化物（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）"  )
len=${#PCode[*]}
let i=0
while ( [ $i -lt  $len ]  )
do 
curl 'http://10.45.100.185/wrpc/wrpc/stats/industry/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: UserLocationfp=http%3A//10.45.100.189/pollution_survey_mybatis_ministry/login/ssoLogin.do%3FpageType%3D3%26ua_account%3D450000893; JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":"450000","contaminant":"fs","contaminantDetail":"'${PCode[$i]}'"}' >./result/分行业统计/"分行业-水-${PName[$i]}.json"

cat  ./result/分行业统计/"分行业-水-${PName[$i]}.json"  |jq -c '.data'  >./result/分行业统计/tmpjson.json
/pucha/puchatool/bin/js2xlsx-huizong-fenhangye.py ./result/分行业统计/tmpjson.json ./result/分行业统计/"分行业-水-${PName[$i]}.xlsx"
let i=$i+1

done
