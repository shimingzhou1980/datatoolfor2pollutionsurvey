#!/bin/bash

###污染源对象数量统计
mkdir -p ./result/分源统计/
##查l
curl 'http://10.45.100.185/wrpc/wrpc/stats/qymlsource/qymlFormQuery' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: UserLocationfp=http%3A//10.45.100.189/pollution_survey_mybatis_ministry/login/ssoLogin.do%3FpageType%3D3%26ua_account%3D450000893; JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"draw":3,"order":[],"pageNum":1,"pageSize":-1,"start":0,"length":-1,"UNIT_ID":"450000893","xzqhDM":"","xzqhMC":""}' >/dev/null

curl 'http://10.45.100.185/wrpc/wrpc/stats/qymlsource/exportExcel' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie: UserLocationfp=http%3A//10.45.100.189/pollution_survey_mybatis_ministry/login/ssoLogin.do%3FpageType%3D3%26ua_account%3D450000893; JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -H 'Upgrade-Insecure-Requests: 1' --data 'unitId=450000893' >./result/分源统计/分源调查对象统计.xlsx



###污染物排放量统计
areacode="450000"





####默认为工业源:gyy,农业源:nyy,生活源:shy,集中式:jzs;移动源:ydy
###废气
PCode=("EYHLPFL" "DYHWPFL" "KLWPFL" "HFXYJWPFL" "ZAPFL" "ZSPFL" "ZQPFL" "ZGPFL" "ZCRPFL" "ZHGPFL")
PName=("二氧化硫（万吨）" "氮氧化物（万吨）" "颗粒物（万吨）" "挥发性有机物（吨）" "氨（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）")

len=${#PCode[*]}
mkdir -p ./result/分源统计

echo "########行政区划代码$areacode的气污染物排放统计情况####"
let i=0
while ( [ $i -lt  $len ]  )
do 

##查询结果直接就是json格式的报表数据
curl 'http://10.45.100.185/wrpc/wrpc/stats/pollutantSource/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: UserLocationfp=http%3A//10.45.100.189/pollution_survey_mybatis_ministry/login/ssoLogin.do%3FpageType%3D3%26ua_account%3D450000893; JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":"450000","contaminant":"fq","contaminantDetail":"'${PCode[$i]}'"}' >./result/分源统计/"分源-气-${PName[$i]}.json"

##转换json到xlsx格式
cat ./result/分源统计/"分源-气-${PName[$i]}.json"  |jq -c '.data'  >./result/分源统计/tmpjson.json
/pucha/puchatool/bin/js2xlsx-huizong-queryfenyuanwuranwupaifang.py  ./result/分源统计/tmpjson.json ./result/分源统计/"分源-气-${PName[$i]}.xlsx"

let i=$i+1
done

###废水
PCode=("HXXYLPFL" "ADPFL" "ZDPFL" "ZLPFL" "SYLPFL" "HFFPFL" "QHWPFL" "ZSPFL" "ZQPFL" "ZGPFL" "ZCRPFL" "ZHGPFL" "WRSHXYLPFL" "DZWYPFL")
PName=("化学需氧量（万吨）" "氨氮（万吨）" "总氮（万吨）" "总磷（万吨）" "石油类（万吨）" "挥发酚（吨）" "氰化物（吨）" "砷（吨）" "铅（吨）" "镉（吨）" "铬（吨）" "汞（吨）" "五日生化需氧量（吨）" "动植物油（吨）")
len=${#PCode[*]}
let i=0
while ( [ $i -lt  $len ]  )
do 

curl 'http://10.45.100.185/wrpc/wrpc/stats/pollutantSource/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":"450000","contaminant":"fs","contaminantDetail":"'${PCode[$i]}'"}' >./result/分源统计/"分源-水-${PName[$i]}.json"
#curl 'http://10.45.100.185/wrpc/wrpc/stats/pollutantSource/queryForm' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: UserLocationfp=http%3A//10.45.100.189/pollution_survey_mybatis_ministry/login/ssoLogin.do%3FpageType%3D3%26ua_account%3D450000893; JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"xzqhdm":"450000","contaminant":"fq","contaminantDetail":"'${PCode[$i]}'"}' >./result/分源统计/"分源-水-${PName[$i]}.json"

##转换json到xlsx格式
cat ./result/分源统计/"分源-水-${PName[$i]}.json"  |jq -c '.data'  >./result/分源统计/tmpjson.json
/pucha/puchatool/bin/js2xlsx-huizong-queryfenyuanwuranwupaifang.py  ./result/分源统计/tmpjson.json ./result/分源统计/"分源-水-${PName[$i]}.xlsx"
let i=$i+1

done
