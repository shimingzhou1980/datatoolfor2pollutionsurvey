#!/bin/bash
mkdir  -p ./result/广西污染物总计/
##普查调查对象统计
curl 'http://10.45.100.185/wrpc/wrpc/home/gj/getListbyPcdx' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"draw":1,"order":[],"pageNum":1,"pageSize":-1,"start":0,"length":-1,"mapping":"getByListPc","xzqhdm":"450000000000"}' 2>&1 >/dev/null 


##导出普查对象统计
curl 'http://10.45.100.185/wrpc/wrpc/home/gj/exportExcelHome' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -H 'Upgrade-Insecure-Requests: 1' --data 'data=%7B%22xzqhdm%22%3A%22450000000000%22%2C%22xzqhmc%22%3A%22%E5%B9%BF%E8%A5%BF%E7%9C%81%22%2C%22wrmc%22%3A%22%E5%B7%A5%E4%B8%9A%E5%BA%9F%E6%B0%B4%E9%87%8F%22%2C%22wrw%22%3A%22W00000%22%2C%22wrwlb%22%3A%222%22%2C%22dw%22%3A%221%22%2C%22exportType%22%3A%221%22%7D' > ./result/广西污染物总计/普查对象统计表.xlsx
###


#
##污染物导出




###气
APCode=("A00000" "A21026" "A21002" "A34000" "A99054" "A21001" "A20007" "A20044" "A20026" "A20033" "A20058")
APName=("工业废气量" "二氧化硫" "氮氧化物" "颗粒物" "挥发性有机物" "氨" "砷" "铅" "镉" "铬" "汞")
##水
WPCode=("W00000" "W01018" "W21003" "W21001" "W21011" "W22001" "W23002" "W21016" "W20119" "W20120" "W20115" "W20116" "W20117" "W20111")
WPName=("工业废水量" "化学需氧量" "氨氮" "总氮" "总磷" "石油类" "挥发酚" "氰化物" "砷" "铅" "镉" "铬" "六价铬" "汞")




####气污染物
len=${#APCode[*]}

let i=0
while ( [ $i -lt  $len ]  )
do 
####由于普查软件查询返回格式不规范，不同污染物有的有全市，有的污染物没有，所以必须在循环里处理

##查询


curl 'http://10.45.100.185/wrpc/wrpc/home/gj/getListbyPcdx' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie: JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"draw":1,"order":[],"pageNum":1,"pageSize":-1,"start":0,"length":-1,"wrwlb":"3","wrw":'"\"${APCode[$i]}\""',"mapping":"getByListQtpfonFq","xzqhdm":"450000000000"}'  2>&1 >/dev/null

###导出###
curl 'http://10.45.100.185/wrpc/wrpc/home/gj/exportExcelHome' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie:  JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -H 'Upgrade-Insecure-Requests: 1' --data 'data={"xzqhdm":"450000000000","xzqhmc":"广西省","wrmc":"'${APName[$i]}'","wrw":"'${APCode[$i]}'","wrwlb":"3","dw":"1","exportType":"2"}'  >./result/广西污染物总计/"气-${APName[$i]}-(单位-立方米-吨).xlsx"

let i=$i+1
done

####水污染物
len=${#WPCode[*]}

let i=0
while ( [ $i -lt  $len ]  )
do 
####由于普查软件查询返回格式不规范，不同污染物有的有全市，有的污染物没有，所以必须在循环里处理

##查询


curl 'http://10.45.100.185/wrpc/wrpc/home/gj/getListbyPcdx' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie:  JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"draw":1,"order":[],"pageNum":1,"pageSize":-1,"start":0,"length":-1,"wrwlb":"2","wrw":'"\"${WPCode[$i]}\""',"mapping":"getByListQtpfonFq","xzqhdm":"450000000000"}'  2>&1 >/dev/null

###导出###




curl 'http://10.45.100.185/wrpc/wrpc/home/gj/exportExcelHome' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie:  JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -H 'Upgrade-Insecure-Requests: 1' --data 'data={"xzqhdm":"450000000000","xzqhmc":"广西省","wrmc":"'${WPName[$i]}'","wrw":"'${WPCode[$i]}'","wrwlb":"2","dw":"1","exportType":"2"}'  >./result/广西污染物总计/"水-${WPName[$i]}-(单位-立方米-吨).xlsx"

let i=$i+1
done



##固体废物

##查询
curl 'http://10.45.100.185/wrpc/wrpc/home/gj/getListbyPcdx' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie:  JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"draw":1,"order":[],"pageNum":1,"pageSize":-1,"start":0,"length":-1,"mapping":"getByListGtpf","xzqhdm":"450000000000"}'  2>&1 >/dev/null

##导出
curl 'http://10.45.100.185/wrpc/wrpc/home/gj/exportExcelHome' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie:  JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -H 'Upgrade-Insecure-Requests: 1' --data 'data=%7B%22xzqhdm%22%3A%22450000000000%22%2C%22xzqhmc%22%3A%22%E5%B9%BF%E8%A5%BF%E7%9C%81%22%2C%22wrmc%22%3A%22%E5%B7%A5%E4%B8%9A%E5%BA%9F%E6%B0%B4%E9%87%8F%22%2C%22wrw%22%3A%22W00000%22%2C%22wrwlb%22%3A%222%22%2C%22dw%22%3A%221%22%2C%22exportType%22%3A%223%22%7D' >./result/广西污染物总计/工业源固体废物贮存处置量-吨.xlsx


###非工业源
#查询
curl 'http://10.45.100.185/wrpc/wrpc/home/gj/getListbyPcdx' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/json;charset=utf-8' -H 'X-Requested-With: XMLHttpRequest' -H 'Connection: keep-alive' -H 'Cookie:  JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' --data '{"draw":1,"order":[],"pageNum":1,"pageSize":-1,"start":0,"length":-1,"mapping":"getByListGtpf","xzqhdm":"450000000000"}'  2>&1 >/dev/null


#导出
curl 'http://10.45.100.185/wrpc/wrpc/home/gj/exportExcelHome' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Referer: http://10.45.100.185/wrpc/view?m=fp' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Connection: keep-alive' -H 'Cookie:  JSESSIONID=CFF6DC4495E198C9A56A0C10BB598F55; route_wrpc=605524f7abe68904b077c0d2cf33f58d; route_tpass=b28882d2c95090138f018b3fdd211bdf' -H 'Upgrade-Insecure-Requests: 1' --data 'data=%7B%22xzqhdm%22%3A%22450000000000%22%2C%22xzqhmc%22%3A%22%E5%B9%BF%E8%A5%BF%E7%9C%81%22%2C%22wrmc%22%3A%22%E5%B7%A5%E4%B8%9A%E5%BA%9F%E6%B0%B4%E9%87%8F%22%2C%22wrw%22%3A%22W00000%22%2C%22wrwlb%22%3A%222%22%2C%22dw%22%3A%221%22%2C%22exportType%22%3A%224%22%7D' >./result/广西污染物总计/非工业源固体废物贮存处置量-吨.xlsx
